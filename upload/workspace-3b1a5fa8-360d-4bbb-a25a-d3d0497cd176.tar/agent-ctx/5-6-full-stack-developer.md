# Task 5-6: Rewrite frontend transfer flow and dialog

## Agent: full-stack-developer

## Summary
Completely rewrote the frontend transfer flow in `/home/z/my-project/src/app/page.tsx` to ensure all transfers happen entirely within the app through the backend API. No `window.open()`, no redirects to Dream11/My11Circle, no clipboard-only flow, no fake success.

## Changes Made

### 1. New State Variables (after line 580)
- `otpState` — stores Dream11's `state` from send-otp response (needed for verify-otp)
- `FantasyAccount` interface — stores authToken, mobileNumber, my11circleChallenge, my11circleUserId, linkedAt
- `fantasyAccounts` — Record<string, FantasyAccount | null> keyed by platform name
- `TransferTeamResult` interface — per-team transfer result with teamNumber, status, message
- `transferResults` — array of TransferTeamResult
- `transferSuccessCount`, `transferFailCount` — running totals during transfer

### 2. Fixed handleSendOTP
- Removed `authToken` from payload — only sends `fantasyApp` and `mobileNumber`
- Changed success check from `data.status === 'success' || res.status === 200` to `data.status === 'success'`
- Stores `data.data.state` in `otpState` for Dream11's verify-otp flow

### 3. Fixed handleVerifyOTP
- Uses `verificationCode` parameter instead of `otp`
- Sends `state` from otpState for Dream11 platform
- Stores `token`, `my11circleChallenge`, `my11circleUserId` from response
- Creates FantasyAccount and saves to both state and localStorage
- Clears `otpState` on success

### 4. Completely Rewrote handleTransfer
- NO clipboard copy, NO window.open, NO fake success
- Checks `fantasyAccounts[transferPlatform]?.authToken` before starting
- Maps player IDs from `fantasy_id_list` to platform-specific IDs
- Calls `/api/fantasy/transfer` per team sequentially
- Rate limiting: 200ms for Dream11, 2000ms for My11Circle
- Tracks per-team results with pending/processing/success/fail states
- Handles edit/replace mode by failing gracefully (needs existing team ID)
- Reports honest success/fail counts

### 5. Added useEffect to Load Fantasy Accounts
- Reads `tg_fantasy_accounts` from localStorage on mount
- Parses and sets fantasyAccounts state

### 6. Completely Rewrote Transfer Dialog
- Auth check uses `fantasyAccounts` instead of `userProfile`
- Green badge with phone number when account is linked
- Amber warning with "Link via OTP →" button when not linked
- Transfer summary shows rate limit info
- Live per-team progress: overall bar + per-team status list (pending/processing/success/fail icons)
- Transfer Complete Summary: all success (green), partial (amber), all failed (red)
- Error state with "Cannot Transfer" + link to OTP login
- Transfer button disabled when no authToken for platform
- Dialog cannot be closed during transfer
- NO "Open Dream11" button, NO "Re-open" button, NO clipboard steps

## Verification
- ESLint passes clean
- No `window.open()` in transfer flow
- No `clipboard` references
- No fake success responses
- Dev server compiles successfully
