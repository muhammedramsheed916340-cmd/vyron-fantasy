---
Task ID: 1
Agent: Main Agent
Task: Upgrade Extra Team Generation with Manual/Auto modes, Avoid players, and auto-replacement

Work Log:
- Added `autoSelectExtraPlayers()` function to `tg-api.ts` that intelligently selects 8 FIX, 5 C, 5 VC using real player data (selection %, captain %, points, playing status, role balance, team balance)
- Added `autoReplacePlayer()` utility function for auto-replacement when a player is removed
- Added `playerScore()` scoring function for ranking players based on actual match data
- Added new state variables: `extraSubMode` (manual/auto), `extraAvoidPlayers`, `extraAutoLastUpdated`
- Added Manual/Auto sub-mode toggle UI within Extra Generation section
- Added Auto mode info banner with "🤖 AUTO SELECTION ACTIVE" message
- Added "Avoid / Exclude Players" section with add/remove functionality
- Added Auto Update button and Last Updated timestamp in auto mode
- Added `handleAutoSelectExtra` callback that runs auto-selection respecting avoid list
- Added `handleExtraRemoveFix/C/VC` handlers that auto-replace removed players in auto mode
- Added lineup safety useEffect that auto-removes OUT players and re-runs auto-select
- Added auto-trigger useEffect that runs auto-select when switching to auto mode
- Updated player picker dialog to support 'avoid' mode with Ban icon
- Fixed player picker `isUsed` logic to properly scope to each picker type

Stage Summary:
- Extra Team Generation now supports Manual and Auto modes
- Auto mode intelligently selects 8 FIX + 5 C + 5 VC from real player data
- Avoid/Exclude players system works - avoided players never selected by auto
- Manual override in auto mode: removing a player auto-replaces with next best
- Lineup safety: OUT players auto-removed and replaced in auto mode
- Normal Team Generation works unchanged (verified with 20-team generation)
- Transfer system works unchanged for both normal and extra generated teams
- All lint checks pass
- Browser verification: Auto mode generates valid 11-player teams with proper C/VC
