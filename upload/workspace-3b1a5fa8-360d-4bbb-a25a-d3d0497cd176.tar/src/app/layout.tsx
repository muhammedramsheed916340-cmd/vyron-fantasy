import type { Metadata } from "next";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

export const metadata: Metadata = {
  title: "Team Generation - Dream11 Team Generator",
  description: "Dream11 Team Generator software also known as Team generation software is the india's best software to create Grand League winning teams in Dream11. This TG software is developed by believer01 youtube channel.",
  keywords: ["Dream11", "Team Generation", "Grand League", "Fantasy Cricket", "TG Software", "Believer01"],
  icons: {
    icon: "/favicon.ico",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="antialiased">
        {children}
        <Toaster />
      </body>
    </html>
  );
}
